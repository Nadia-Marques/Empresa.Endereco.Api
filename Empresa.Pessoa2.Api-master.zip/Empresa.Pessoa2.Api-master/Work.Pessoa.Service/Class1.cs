﻿namespace Work.Pessoa.Service
{
    public class Class1
    {

    }
}
