﻿namespace Work.Pessoa.Domain
{
    public class Class1
    {

    }
}
